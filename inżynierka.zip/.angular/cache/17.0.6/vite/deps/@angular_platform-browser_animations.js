import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-LKASLRUB.js";
import "./chunk-JKKCKGJJ.js";
import "./chunk-BQCFEHIH.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-LMIY3IUR.js";
import "./chunk-SY23PRBX.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
