import {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
} from "./chunk-QXWMMWDJ.js";
import "./chunk-PVUM5VHB.js";
import "./chunk-QN2HMQF7.js";
import "./chunk-2RL6KXIS.js";
import "./chunk-3A7CV2AC.js";
import "./chunk-BQCFEHIH.js";
import "./chunk-LMIY3IUR.js";
import "./chunk-SY23PRBX.js";
export {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
};
//# sourceMappingURL=@angular_fire_compat_auth.js.map
