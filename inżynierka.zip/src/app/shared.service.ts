import { Injectable, Query } from '@angular/core';
import { Firestore, addDoc, collection, collectionData, deleteDoc, doc,query,where,getDocs } from '@angular/fire/firestore';
import { Data } from '@angular/router';




@Injectable({
  providedIn: 'root'
})

export class SharedService {

  constructor(private fs:Firestore) { }


  getOpony(){

    let oponyCollection = collection(this.fs,'Opony');
    return collectionData(oponyCollection,{idField:'id'});
  }


  addOpony(desc:Data){

    let data = desc;
    let oponyCollection = collection(this.fs, 'Opony');
    return addDoc(oponyCollection,data);
  }

  deleteOpony(id:string){

    let docRef = doc(this.fs,'Opony/'+id);
    return deleteDoc(docRef);

  }




}
