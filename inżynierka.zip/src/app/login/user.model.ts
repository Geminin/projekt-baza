export interface User {
  uid: string;
  email: string;
  name: string;
  isAdmin: boolean;
}